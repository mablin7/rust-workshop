fn main() {
    // Declare a variable
    let x = 10;

    // Print its value
    println!("x = {}", x);

    // Try changing the variable

    // Make it mutable

    // Try changing the variable again

    // Try shadowing the variable
}
