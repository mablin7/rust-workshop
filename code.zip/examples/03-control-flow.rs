fn main() {
    // Declare a variable named `x` 

    // Create a scope and declare a variable named `y` in it. Print `x + y` from the scope.
    {

    };

    // Create a scope that returns `x + y` from it, assign it to a variable named `z` and print it.

    // Use if/else to print whether z is greater than 1 or not.

    // Use a `loop` to print `z` 5 times.

    // Use a while loop to print `z` 5 times (use an additional counter variable).

    // Use if else to declare a variable that is true if `z` is greater than 1 and false otherwise.

    // Use a loop that returns the first randomly generated value that is greater than 0.5 (use the function `rand::random::<f64>()` to get a random float between 0 and 1).

    // Use a for loop to print the numbers 1 to 10.

    // Use a for loop to iterate throuth and array
}
